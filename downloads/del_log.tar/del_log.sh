#!/bin/bash
# del log
# Création F1IZL 
# Vous pouvez les chemins en fonction de vos configurations

# Remove MMDVMHost Logs 
rm -Rf /home/pi/Applications/MMDVMHost/MMDVM-*.log

# Remove YSFGateway Logs
rm -Rf /home/pi/Applications/YSFClients/YSFGateway/YSFGateway-*.log

# Clear Bash History
cat /dev/null > /home/pi/.bash_history
history -c
sudo pkill MMDCMHost
sh -c "sudo systemctl restart mmdvmhost.service ; sudo screen -r MMDVMHost"
